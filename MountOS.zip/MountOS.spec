# -*- mode: python ; coding: utf-8 -*-
"""
MountOS — PyInstaller spec.
Собирает один .exe со всем: Python, PySide6, QtWebEngine, приложения.
"""

from PyInstaller.utils.hooks import collect_submodules, collect_data_files
from PyInstaller.utils.hooks import collect_dynamic_libs
from pathlib import Path

BASE = Path(SPECPATH)   # папка проекта

# ---- Встроенные приложения MountOS (apps/) ----
# Их надо положить в сборку как данные, чтобы PyInstaller их не пытался импортить
app_datas = [
    (str(BASE / "apps" / "files.py"), "apps"),
    (str(BASE / "apps" / "terminal.py"), "apps"),
    (str(BASE / "apps" / "notes.py"), "apps"),
    (str(BASE / "apps" / "settings.py"), "apps"),
    (str(BASE / "apps" / "calculator.py"), "apps"),
    (str(BASE / "apps" / "gallery.py"), "apps"),
    (str(BASE / "apps" / "music.py"), "apps"),
    (str(BASE / "apps" / "taskmgr.py"), "apps"),
    (str(BASE / "apps" / "clock.py"), "apps"),
    (str(BASE / "apps" / "calendar.py"), "apps"),
    (str(BASE / "apps" / "text_editor.py"), "apps"),
    (str(BASE / "apps" / "browser.py"), "apps"),
    (str(BASE / "apps" / "__init__.py"), "apps"),
]

# ---- system/ (модули ядра + user_data начальная) ----
system_datas = [
    (str(BASE / "system" / "__init__.py"), "system"),
    (str(BASE / "system" / "vfs.py"), "system"),
    (str(BASE / "system" / "registry.py"), "system"),
    (str(BASE / "system" / "app_loader.py"), "system"),
    (str(BASE / "system" / "settings_store.py"), "system"),
    (str(BASE / "system" / "notify_history.py"), "system"),
    (str(BASE / "system" / "i18n.py"), "system"),
    (str(BASE / "system" / "paths.py"), "system"),
    (str(BASE / "system" / "blur.py"), "system"),
]

# ---- ui/ ----
ui_datas = [(str(BASE / "ui" / f), "ui")
            for f in [
                "__init__.py", "desktop.py", "panel.py", "dock.py",
                "taskbar.py", "glass_window.py", "widgets.py",
                "widget_base.py", "shortcuts.py", "desktop_menu.py",
                "context_menu.py", "notifications.py", "notif_center.py",
                "app_menu.py", "spotlight.py", "hotkeys.py", "icons.py",
                "settings_state.py",
            ]]

datas = app_datas + system_datas + ui_datas

# ---- Пользовательские приложения (примеры) ----
user_apps_dir = BASE / "system" / "user_apps"
if user_apps_dir.exists():
    for f in user_apps_dir.glob("*.py"):
        datas.append((str(f), "system/user_apps"))

# ---- QtWebEngine ресурсы (это ОБЯЗАТЕЛЬНО, иначе браузер упадёт) ----
try:
    datas += collect_data_files("PySide6", subdir="Qt")
    datas += collect_data_files("PySide6", subdir="resources")
    datas += collect_data_files("PySide6", subdir="translations")
except Exception as e:
    print(f"[spec] WARN: QtWebEngine datas: {e}")

# ---- Скрытые импорты (PySide6 их не помечает) ----
hiddenimports = [
    "PySide6.QtCore",
    "PySide6.QtGui",
    "PySide6.QtWidgets",
    "PySide6.QtMultimedia",
    "PySide6.QtWebEngineWidgets",
    "PySide6.QtWebEngineCore",
    "PySide6.QtWebChannel",
    "PySide6.QtNetwork",
    "PySide6.QtSvg",
    "PySide6.QtPrintSupport",
]

# Дополнительные модули приложений
for mod in ["apps", "system", "ui"]:
    try:
        hiddenimports += collect_submodules(mod)
    except Exception:
        pass

# ---- QtWebEngine DLL (без них Chromium не поднимется) ----
binaries = []
try:
    binaries += collect_dynamic_libs("PySide6")
except Exception:
    pass


block_cipher = None


a = Analysis(
    ["main.py"],
    pathex=[str(BASE)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "matplotlib",
        "numpy",
        "pandas",
        "scipy",
        "PIL",
        "test",
        "unittest",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)


exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="MountOS",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                     # сжатие (может замедлить запуск)
    console=False,                # console=True — если хочешь видеть логи
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,                    # путь к .ico если есть
)


coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="MountOS",
)