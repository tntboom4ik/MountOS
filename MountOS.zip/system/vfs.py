"""
MountOS Virtual File System.
Песочница в system/user_data/ — приложения работают только здесь.
"""
import os
import shutil
import json
from pathlib import Path


class VFS:
    def __init__(self, base_dir):
        self.root = Path(base_dir) / "system" / "user_data" / "home"
        self.root.mkdir(parents=True, exist_ok=True)

    # ---- Пути ----
    def _resolve(self, path: str) -> Path:
        """Превращает /Documents/foo.txt в абсолютный путь внутри root."""
        if not path or path == "/":
            return self.root
        clean = path.lstrip("/").replace("\\", "/")
        target = (self.root / clean).resolve()
        # Защита от выхода за пределы песочницы
        try:
            target.relative_to(self.root.resolve())
        except ValueError:
            raise PermissionError(f"Путь вне песочницы MountOS: {path}")
        return target

    def home(self) -> str:
        return "/"

    # ---- Чтение ----
    def listdir(self, path: str = "/"):
        p = self._resolve(path)
        if not p.exists():
            return []
        items = []
        for entry in sorted(p.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower())):
            try:
                stat = entry.stat()
                items.append({
                    "name": entry.name,
                    "path": self._to_vpath(entry),
                    "is_dir": entry.is_dir(),
                    "size": 0 if entry.is_dir() else stat.st_size,
                    "mtime": stat.st_mtime,
                })
            except (OSError, PermissionError):
                continue
        return items

    def exists(self, path: str) -> bool:
        try:
            return self._resolve(path).exists()
        except PermissionError:
            return False

    def is_dir(self, path: str) -> bool:
        try:
            return self._resolve(path).is_dir()
        except PermissionError:
            return False

    def read_text(self, path: str, default="") -> str:
        p = self._resolve(path)
        if not p.exists():
            return default
        try:
            return p.read_text(encoding="utf-8")
        except Exception:
            return default

    def read_bytes(self, path: str) -> bytes:
        return self._resolve(path).read_bytes()

    # ---- Запись ----
    def write_text(self, path: str, text: str):
        p = self._resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")

    def write_bytes(self, path: str, data: bytes):
        p = self._resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def mkdir(self, path: str):
        self._resolve(path).mkdir(parents=True, exist_ok=True)

    def delete(self, path: str):
        p = self._resolve(path)
        if not p.exists():
            return
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()

    def rename(self, old: str, new: str):
        self._resolve(old).rename(self._resolve(new))

    def copy(self, src: str, dst: str):
        s = self._resolve(src)
        d = self._resolve(dst)
        if s.is_dir():
            shutil.copytree(s, d)
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, d)

    # ---- Утилиты ----
    def _to_vpath(self, p: Path) -> str:
        rel = p.relative_to(self.root)
        return "/" + str(rel).replace("\\", "/")

    def join(self, *parts) -> str:
        joined = "/".join(str(p).strip("/") for p in parts if p)
        return "/" + joined

    def basename(self, path: str) -> str:
        return os.path.basename(path.rstrip("/")) or "/"

    def parent(self, path: str) -> str:
        path = path.rstrip("/")
        if not path or path == "/":
            return "/"
        p = os.path.dirname(path)
        return p or "/"

    # ---- Инициализация при первом запуске ----
    def ensure_default_structure(self):
        for folder in ["Documents", "Pictures", "Notes", "Downloads"]:
            self.mkdir(f"/{folder}")

        # Приветственный файл
        readme = "/Documents/readme.txt"
        if not self.exists(readme):
            self.write_text(readme,
                "Добро пожаловать в MountOS!\n\n"
                "Это виртуальная файловая система.\n"
                "Всё, что ты создаёшь здесь — лежит в\n"
                "system/user_data/home/ и не трогает реальный диск.\n"
            )