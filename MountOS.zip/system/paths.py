"""
MountOS — Единая точка путей проекта.
Работает и как .py, и как собранный .exe (PyInstaller).
"""
from pathlib import Path
import sys
import os


# ============================================================
#  Определение корня проекта
# ============================================================

def _get_base_dir() -> Path:
    """
    - При обычном запуске: папка, где лежит main.py
    - При запуске из PyInstaller .exe: папка рядом с .exe
      (не _MEIPASS — потому что там user_data должна быть изменяемой)
    """
    if getattr(sys, "frozen", False):
        # Собранный .exe — BASE = папка, где лежит сам exe
        return Path(sys.executable).resolve().parent
    else:
        # Обычный запуск — BASE = корень проекта
        return Path(__file__).resolve().parent.parent


def _get_bundle_dir() -> Path:
    """
    Папка, где PyInstaller распаковал ВСТРОЕННЫЕ файлы (только для чтения).
    При обычном запуске = BASE.
    """
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", _get_base_dir()))
    return _get_base_dir()


BASE = _get_base_dir()
BUNDLE = _get_bundle_dir()


# ============================================================
#  Данные пользователя (изменяемые — рядом с exe)
# ============================================================

USER_DATA = BASE / "system" / "user_data"
USER_DATA.mkdir(parents=True, exist_ok=True)

DESKTOP_JSON  = USER_DATA / "desktop.json"
SETTINGS_JSON = USER_DATA / "settings.json"
NOTIF_HISTORY = USER_DATA / "notifications.json"

HOME_DIR   = USER_DATA / "home"
NOTES_DIR  = HOME_DIR / "Notes"
MUSIC_DIR  = HOME_DIR / "Music"
PICS_DIR   = HOME_DIR / "Pictures"
DOCS_DIR   = HOME_DIR / "Documents"


# ============================================================
#  Встроенные приложения (в exe — в _MEIPASS, рядом с exe — в apps/)
# ============================================================

APPS_DIR = BUNDLE / "apps"
USER_APPS_DIR = BASE / "system" / "user_apps"
USER_APPS_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
#  Платформа
# ============================================================

def _detect_platform() -> str:
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform.startswith("linux"):
        return "linux"
    if sys.platform.startswith("darwin"):
        return "macos"
    return "unknown"


PLATFORM   = _detect_platform()
IS_WINDOWS = PLATFORM == "windows"
IS_LINUX   = PLATFORM == "linux"
IS_MACOS   = PLATFORM == "macos"
IS_UNKNOWN = PLATFORM == "unknown"

IS_FROZEN = getattr(sys, "frozen", False)


# ============================================================
#  Утилита
# ============================================================

def app_data_dir(app_id: str) -> Path:
    d = USER_DATA / "apps" / app_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def first_run_init():
    """
    Если это первый запуск exe — раскладываем базовую структуру.
    Вызывается из main.py при старте.
    """
    # Гарантируем папку user_apps
    USER_APPS_DIR.mkdir(parents=True, exist_ok=True)

    # Гарантируем домашнюю папку VFS
    HOME_DIR.mkdir(parents=True, exist_ok=True)
    for sub in ("Documents", "Pictures", "Notes", "Downloads", "Music"):
        (HOME_DIR / sub).mkdir(parents=True, exist_ok=True)