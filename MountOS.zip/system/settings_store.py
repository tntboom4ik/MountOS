"""
MountOS — Хранилище настроек.
Сохраняет SettingsState в JSON между запусками.
"""
import json
from pathlib import Path


class SettingsStore:
    """Простое JSON-хранилище ключ→значение."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data = {}
        self.load()

    def load(self):
        if not self.path.exists():
            self._data = {}
            return
        try:
            raw = self.path.read_text(encoding="utf-8")
            self._data = json.loads(raw) if raw.strip() else {}
        except Exception as e:
            print(f"[SettingsStore] не удалось прочитать {self.path}: {e}")
            self._data = {}

    def save(self):
        try:
            self.path.write_text(
                json.dumps(self._data, indent=2, ensure_ascii=False),
                encoding="utf-8")
        except Exception as e:
            print(f"[SettingsStore] не удалось записать {self.path}: {e}")

    def get(self, key, default=None):
        return self._data.get(key, default)

    def set(self, key, value):
        self._data[key] = value
        self.save()

    def delete(self, key):
        if key in self._data:
            del self._data[key]
            self.save()

    def clear(self):
        self._data = {}
        self.save()

    def all(self):
        return dict(self._data)

    def __contains__(self, key):
        return key in self._data

    def __repr__(self):
        return f"<SettingsStore path={self.path} keys={list(self._data.keys())}>"