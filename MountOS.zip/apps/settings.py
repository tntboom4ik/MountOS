"""
MountOS — Настройки.
Только рабочие параметры. Локализация RU/EN.
English помечен как Beta.
"""
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QLabel,
                                QPushButton, QStackedWidget, QCheckBox,
                                QSlider, QScrollArea, QFrame, QFileDialog,
                                QMessageBox, QApplication)
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QLinearGradient, QFont
import platform
import sys
import time

from ui.settings_state import state
from ui.icons import get_icon
from system.i18n import (tr, on_change, available_languages,
                         current_language, is_beta, language_status)
from ui.hotkeys import HOTKEYS_HELP

APP_NAME = "Настройки"
APP_ICON = "settings"
APP_VERSION = "0.5"
APP_AUTHOR = "MountOS"


_START_TIME = time.time()


# ============================================================
#  Поиск Desktop / Registry
# ============================================================

def _get_desktop(widget):
    p = widget
    while p is not None:
        if hasattr(p, "notifications") and hasattr(p, "open_app"):
            return p
        p = p.parent()

    for top in QApplication.topLevelWidgets():
        ref = getattr(top, "desktop_ref", None)
        if ref is not None and hasattr(ref, "registry"):
            return ref
        for child in top.findChildren(QWidget):
            ref = getattr(child, "desktop_ref", None)
            if ref is not None and hasattr(ref, "registry"):
                return ref
    for top in QApplication.topLevelWidgets():
        if hasattr(top, "notifications") and hasattr(top, "open_app"):
            return top
    return None


def _get_registry(widget):
    d = _get_desktop(widget)
    if d is not None and hasattr(d, "registry"):
        return d.registry
    return None


# ============================================================
#  Хелперы
# ============================================================

def _section(text):
    l = QLabel(text.upper())
    l.setStyleSheet("""
        color: rgba(255,255,255,0.45);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1.5px;
        padding: 16px 4px 8px 4px;
    """)
    return l


def _hint(text):
    l = QLabel(text)
    l.setWordWrap(True)
    l.setStyleSheet("color: rgba(255,255,255,0.45); font-size: 11px; padding: 2px 4px 6px 4px;")
    return l


def _row(label, widget):
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(4, 6, 4, 6)
    lbl = QLabel(label)
    lbl.setStyleSheet("color: rgba(255,255,255,0.90); font-size: 13px;")
    lay.addWidget(lbl)
    lay.addStretch(1)
    lay.addWidget(widget)
    return w


def _checkbox(key, default=None):
    cb = QCheckBox()
    val = state().get(key, default if default is not None else True)
    cb.setChecked(val)
    cb.stateChanged.connect(lambda v: state().set(key, bool(v)))
    cb.setStyleSheet("""
        QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px; }
        QCheckBox::indicator:unchecked {
            border: 1px solid rgba(255,255,255,0.30);
            background: rgba(255,255,255,0.05);
        }
        QCheckBox::indicator:checked {
            border: 1px solid #6EC6FF;
            background: #6EC6FF;
        }
    """)
    return cb


def _slider(key, minv, maxv, is_float=False):
    sl = QSlider(Qt.Horizontal)
    sl.setRange(minv, maxv)
    sl.setFixedWidth(220)
    cur = state().get(key)
    sl.setValue(int(cur * 100) if is_float else int(cur))
    sl.setStyleSheet("""
        QSlider::groove:horizontal {
            height: 4px; background: rgba(255,255,255,0.15);
            border-radius: 2px;
        }
        QSlider::handle:horizontal {
            background: #6EC6FF; width: 16px; margin: -6px 0;
            border-radius: 8px;
        }
    """)
    def on_change_val(v):
        state().set(key, v / 100.0 if is_float else v)
    sl.valueChanged.connect(on_change_val)
    return sl


def _scrollable(inner):
    sc = QScrollArea()
    sc.setWidgetResizable(True)
    sc.setFrameShape(QFrame.NoFrame)
    sc.setStyleSheet("""
        QScrollArea { background: transparent; }
        QScrollBar:vertical {
            background: transparent; width: 8px; margin: 4px;
        }
        QScrollBar::handle:vertical {
            background: rgba(255,255,255,0.20);
            border-radius: 4px; min-height: 30px;
        }
        QScrollBar::handle:vertical:hover { background: rgba(255,255,255,0.35); }
        QScrollBar::add-line, QScrollBar::sub-line { height: 0; }
    """)
    sc.setWidget(inner)
    return sc


# ============================================================
#  Обои
# ============================================================

WALLPAPERS = {
    "cosmic":    (("#0A0E1A", "#131A2E", "#1A1F35"),
                  (110, 198, 255), (179, 136, 255)),
    "mountains": (("#101820", "#1F2D3A", "#354A5E"),
                  (140, 200, 180), (200, 220, 200)),
    "neon":      (("#160020", "#2A0050", "#4A0080"),
                  (255, 80, 200), (120, 100, 255)),
    "aurora":    (("#021B1B", "#053B3B", "#0A5C5C"),
                  (100, 255, 200), (150, 200, 255)),
}


# ============================================================
#  Страницы
# ============================================================

def _page_about():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 30, 30, 30)
    lay.setSpacing(8)

    logo = QLabel()
    logo.setAlignment(Qt.AlignCenter)
    pm = QPixmap(140, 140)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    grad = QLinearGradient(0, 0, 140, 140)
    accent = state().get("accent")
    grad.setColorAt(0, QColor(accent))
    grad.setColorAt(1, QColor(179, 136, 255))
    p.setBrush(grad); p.setPen(Qt.NoPen)
    p.drawEllipse(20, 20, 100, 100)
    p.setPen(QColor("white"))
    p.setFont(QFont("Segoe UI", 48, QFont.Light))
    p.drawText(pm.rect(), Qt.AlignCenter, "◆")
    p.end()
    logo.setPixmap(pm)
    lay.addWidget(logo)

    name = QLabel("MountOS")
    name.setAlignment(Qt.AlignCenter)
    name.setStyleSheet("""
        color: white; font-size: 34px;
        font-weight: 300; letter-spacing: 6px;
    """)
    lay.addWidget(name)

    ver = QLabel(tr("settings.about.version", v="0.5", c="Liquid Glass"))
    ver.setAlignment(Qt.AlignCenter)
    ver.setStyleSheet("color: rgba(255,255,255,0.55); font-size: 13px; letter-spacing: 1px;")
    lay.addWidget(ver)

    lay.addSpacing(30)

    import PySide6
    info = [
        (tr("settings.about.system"),   f"{platform.system()} {platform.release()}"),
        (tr("settings.about.python"),   platform.python_version()),
        (tr("settings.about.pyside"),   PySide6.__version__),
        (tr("settings.about.kernel"),   "MountKernel 0.5"),
        (tr("settings.about.shell"),    "Liquid Glass UI"),
        (tr("settings.about.arch"),     platform.machine()),
        (tr("settings.about.host"),     platform.node()),
    ]
    try:
        from system.paths import PLATFORM
        info.append((tr("settings.about.platform"), PLATFORM))
    except Exception:
        pass

    for k, v in info:
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(20, 8, 20, 8)
        kl = QLabel(k); kl.setStyleSheet("color: rgba(255,255,255,0.60); font-size: 13px;")
        vl = QLabel(str(v)); vl.setStyleSheet("color: rgba(255,255,255,0.95); font-size: 13px; font-weight: 500;")
        rl.addWidget(kl); rl.addStretch(1); rl.addWidget(vl)
        row.setStyleSheet("QWidget { background: rgba(255,255,255,0.05); border-radius: 10px; margin: 2px 0; }")
        lay.addWidget(row)

    lay.addStretch(1)
    return _scrollable(w)


def _page_appearance():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(2)

    lay.addWidget(_section(tr("settings.appearance.accent")))
    lay.addWidget(_hint(tr("settings.appearance.accent_hint")))
    accents_row = QWidget()
    ar = QHBoxLayout(accents_row)
    ar.setContentsMargins(4, 4, 4, 12)
    ar.setSpacing(10)
    for hexc, name in [
        ("#6EC6FF", "Blue"),
        ("#B388FF", "Purple"),
        ("#FF6B8A", "Pink"),
        ("#6EE7B7", "Green"),
        ("#FFB86C", "Orange"),
    ]:
        b = QPushButton()
        b.setFixedSize(38, 38)
        b.setCursor(Qt.PointingHandCursor)
        b.setToolTip(name)
        b.clicked.connect(lambda _, h=hexc: state().set("accent", h))
        def refresh(btn=b, h=hexc):
            cur = state().get("accent") == h
            border = "3px solid white" if cur else "1px solid rgba(255,255,255,0.30)"
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: {h};
                    border: {border};
                    border-radius: 19px;
                }}
            """)
        refresh()
        state().changed.connect(lambda k, v, f=refresh: f() if k == "accent" else None)
        ar.addWidget(b)
    ar.addStretch(1)
    lay.addWidget(accents_row)

    lay.addWidget(_section(tr("settings.appearance.windows")))
    lay.addWidget(_row(tr("settings.appearance.opacity"),
                       _slider("window_opacity", 40, 100, is_float=True)))
    lay.addWidget(_hint(tr("settings.appearance.opacity_hint")))
    lay.addWidget(_row(tr("settings.appearance.radius"),
                       _slider("window_radius", 8, 30)))
    lay.addWidget(_hint(tr("settings.appearance.radius_hint")))
    lay.addWidget(_row(tr("settings.appearance.blur"),
                       _checkbox("blur_enabled")))
    lay.addWidget(_hint(tr("settings.appearance.blur_hint")))

    lay.addWidget(_section(tr("settings.appearance.interface")))
    lay.addWidget(_row(tr("settings.appearance.clock"),
                       _checkbox("show_clock")))
    lay.addWidget(_row(tr("settings.appearance.dock"),
                       _checkbox("show_dock")))
    lay.addWidget(_row(tr("settings.appearance.welcome"),
                       _checkbox("show_welcome")))

    lay.addStretch(1)
    return _scrollable(w)


def _page_wallpaper():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(2)

    lay.addWidget(_section(tr("settings.wallpaper.title")))
    lay.addWidget(_hint(tr("settings.wallpaper.hint")))

    grid = QWidget()
    gl = QHBoxLayout(grid)
    gl.setContentsMargins(4, 8, 4, 8)
    gl.setSpacing(14)

    def make_preview(key):
        colors, g1, g2 = WALLPAPERS[key]
        pm = QPixmap(160, 100)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        grad = QLinearGradient(0, 0, 160, 100)
        grad.setColorAt(0, QColor(colors[0]))
        grad.setColorAt(0.5, QColor(colors[1]))
        grad.setColorAt(1, QColor(colors[2]))
        p.fillRect(0, 0, 160, 100, grad)
        g = QLinearGradient(0, 0, 100, 100)
        g.setColorAt(0, QColor(*g1, 90))
        g.setColorAt(1, QColor(*g1, 0))
        p.setBrush(g); p.setPen(Qt.NoPen)
        p.drawEllipse(-20, -20, 120, 120)
        g2_ = QLinearGradient(160, 100, 60, 0)
        g2_.setColorAt(0, QColor(*g2, 80))
        g2_.setColorAt(1, QColor(*g2, 0))
        p.setBrush(g2_)
        p.drawEllipse(60, 20, 130, 130)
        p.end()
        return pm

    buttons = []

    def refresh_all():
        for key, b in buttons:
            selected = state().get("wallpaper") == key
            border = "3px solid #6EC6FF" if selected else "2px solid rgba(255,255,255,0.10)"
            b.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    border: {border};
                    border-radius: 14px;
                    padding: 4px;
                }}
                QPushButton:hover {{ border: 2px solid rgba(255,255,255,0.40); }}
            """)

    state().changed.connect(lambda k, v: refresh_all() if k == "wallpaper" else None)

    names = {
        "cosmic":    tr("settings.wallpaper.cosmic"),
        "mountains": tr("settings.wallpaper.mountains"),
        "neon":      tr("settings.wallpaper.neon"),
        "aurora":    tr("settings.wallpaper.aurora"),
    }
    for key in WALLPAPERS:
        b = QPushButton()
        b.setIcon(QIcon(make_preview(key)))
        b.setIconSize(QSize(160, 100))
        b.setFixedSize(176, 116)
        b.setCursor(Qt.PointingHandCursor)
        b.setToolTip(names.get(key, key))
        b.clicked.connect(lambda _, k=key: state().set("wallpaper", k))
        buttons.append((key, b))
        gl.addWidget(b)

    gl.addStretch(1)
    refresh_all()
    lay.addWidget(grid)

    lay.addWidget(_section(tr("settings.wallpaper.startup")))
    lay.addWidget(_row(tr("settings.wallpaper.notif"),
                       _checkbox("show_startup_notification")))

    lay.addStretch(1)
    return _scrollable(w)


def _page_language():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(10)

    lay.addWidget(_section(tr("settings.language.title")))
    lay.addWidget(_hint(tr("settings.language.hint")))

    # ---- Предупреждение о Beta (показывается только если выбран beta-язык) ----
    beta_note = QLabel(tr("settings.language.beta_note"))
    beta_note.setWordWrap(True)
    beta_note.setStyleSheet("""
        background: rgba(255,184,108,0.15);
        color: #FFD0A0;
        border: 1px solid rgba(255,184,108,0.45);
        border-radius: 10px;
        padding: 10px 14px;
        font-size: 12px;
    """)
    lay.addWidget(beta_note)

    buttons = []
    badge_labels = []

    def refresh():
        cur = current_language()
        for code, btn in buttons:
            active = (code == cur)
            if active:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(110,198,255,0.30);
                        color: white;
                        border: 1px solid rgba(110,198,255,0.70);
                        border-radius: 14px;
                        padding: 16px 20px;
                        font-size: 15px;
                        font-weight: 600;
                        text-align: left;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(255,255,255,0.05);
                        color: rgba(255,255,255,0.85);
                        border: 1px solid rgba(255,255,255,0.10);
                        border-radius: 14px;
                        padding: 16px 20px;
                        font-size: 15px;
                        text-align: left;
                    }
                    QPushButton:hover {
                        background: rgba(255,255,255,0.12);
                    }
                """)
        # Скрываем инфо-плашку, если выбран не beta-язык
        beta_note.setVisible(is_beta(cur))

    def make_row(code, name, flag, status):
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(10)

        b = QPushButton(f"   {flag}   {name}")
        b.setCursor(Qt.PointingHandCursor)
        b.setFixedHeight(60)
        def on_click(_, c=code):
            state().set("language", c)
            refresh()
        b.clicked.connect(on_click)
        rl.addWidget(b, 1)
        buttons.append((code, b))

        # Плашка "Beta" справа
        if status == "beta":
            badge = QLabel("Beta")
            badge.setStyleSheet("""
                background: rgba(255,184,108,0.20);
                color: #FFB86C;
                border: 1px solid rgba(255,184,108,0.55);
                border-radius: 9px;
                padding: 4px 12px;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
            """)
            badge.setAlignment(Qt.AlignCenter)
            badge.setFixedHeight(26)
            rl.addWidget(badge)
            badge_labels.append(badge)
        else:
            # Пустое место, чтобы выровнять
            placeholder = QWidget()
            placeholder.setFixedWidth(64)
            rl.addWidget(placeholder)

        return row

    for code, name, flag, status in available_languages():
        lay.addWidget(make_row(code, name, flag, status))

    refresh()
    lay.addStretch(1)
    return _scrollable(w)


def _page_apps():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(6)

    lay.addWidget(_section(tr("settings.apps.actions")))
    lay.addWidget(_hint(tr("settings.apps.install_hint")))

    btn_row = QWidget()
    br = QHBoxLayout(btn_row)
    br.setContentsMargins(4, 6, 4, 12)
    br.setSpacing(10)

    install_btn = QPushButton(f"  {tr('settings.apps.install')}")
    install_btn.setIcon(QIcon(get_icon("plus", 20, "#6EC6FF")))
    install_btn.setCursor(Qt.PointingHandCursor)
    install_btn.setStyleSheet("""
        QPushButton {
            background: rgba(110,198,255,0.18);
            color: white; border: 1px solid rgba(110,198,255,0.55);
            border-radius: 10px; padding: 10px 18px; font-size: 13px;
        }
        QPushButton:hover { background: rgba(110,198,255,0.35); }
    """)
    br.addWidget(install_btn)

    refresh_btn = QPushButton(f"  {tr('settings.apps.refresh')}")
    refresh_btn.setCursor(Qt.PointingHandCursor)
    refresh_btn.setStyleSheet("""
        QPushButton {
            background: rgba(255,255,255,0.08);
            color: white; border: 1px solid rgba(255,255,255,0.15);
            border-radius: 10px; padding: 10px 18px; font-size: 13px;
        }
        QPushButton:hover { background: rgba(255,255,255,0.18); }
    """)
    br.addWidget(refresh_btn)
    br.addStretch(1)
    lay.addWidget(btn_row)

    lay.addWidget(_section(tr("settings.apps.list")))
    lay.addWidget(_hint(tr("settings.apps.delete_hint")))

    list_holder = QWidget()
    lh = QVBoxLayout(list_holder)
    lh.setContentsMargins(0, 0, 0, 0)
    lh.setSpacing(6)
    lay.addWidget(list_holder)

    def rebuild():
        _rebuild_app_list(w, list_holder)

    install_btn.clicked.connect(lambda: _install_from_settings(w, rebuild))
    refresh_btn.clicked.connect(rebuild)
    rebuild()

    lay.addStretch(1)
    return _scrollable(w)


def _rebuild_app_list(parent_widget, holder):
    for i in reversed(range(holder.layout().count())):
        it = holder.layout().itemAt(i)
        if it and it.widget():
            it.widget().setParent(None)

    reg = _get_registry(parent_widget)
    if reg is None:
        lbl = QLabel(tr("settings.apps.registry_error"))
        lbl.setStyleSheet("color: #FFA0B4; font-size: 12px; padding: 10px;")
        lbl.setWordWrap(True)
        holder.layout().addWidget(lbl)
        return

    if not reg.apps:
        lbl = QLabel(tr("settings.apps.none"))
        lbl.setStyleSheet("color: rgba(255,255,255,0.55); font-size: 12px;")
        holder.layout().addWidget(lbl)
        return

    items = sorted(reg.apps.items(),
                   key=lambda kv: (not kv[1].builtin, kv[1].name.lower()))

    for app_id, info in items:
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(14, 8, 10, 8)
        rl.setSpacing(12)

        ic = QLabel()
        ic.setPixmap(get_icon(info.app_id, 24, state().get("accent")))
        rl.addWidget(ic)

        name = QLabel(info.name)
        name.setStyleSheet("color: rgba(255,255,255,0.92); font-size: 13px; font-weight: 500;")
        rl.addWidget(name)

        meta = QLabel(f"v{info.version} · {info.author}")
        meta.setStyleSheet("color: rgba(255,255,255,0.45); font-size: 11px;")
        rl.addWidget(meta)

        rl.addStretch(1)

        tag_text = tr("settings.apps.builtin") if info.builtin else tr("settings.apps.custom")
        tag = QLabel(tag_text)
        tag.setStyleSheet(f"""
            color: {'#6EC6FF' if info.builtin else '#FFB86C'};
            font-size: 10px;
            letter-spacing: 1px;
            padding: 3px 8px;
            border: 1px solid {'rgba(110,198,255,0.45)' if info.builtin else 'rgba(255,184,108,0.45)'};
            border-radius: 8px;
        """)
        rl.addWidget(tag)

        if not info.builtin:
            trash = QPushButton()
            trash.setIcon(QIcon(get_icon("trash", 18, "#FFA0B4")))
            trash.setFixedSize(32, 32)
            trash.setCursor(Qt.PointingHandCursor)
            trash.setStyleSheet("""
                QPushButton {
                    background: rgba(255,107,138,0.15);
                    border: 1px solid rgba(255,107,138,0.40);
                    border-radius: 8px;
                }
                QPushButton:hover { background: rgba(255,107,138,0.35); }
            """)
            trash.clicked.connect(
                lambda _, a=app_id, p=parent_widget, h=holder: _do_remove(p, h, a))
            rl.addWidget(trash)

        row.setStyleSheet("""
            QWidget { background: rgba(255,255,255,0.05); border-radius: 12px; }
            QWidget:hover { background: rgba(255,255,255,0.08); }
        """)
        holder.layout().addWidget(row)


def _do_remove(parent_widget, holder, app_id):
    reg = _get_registry(parent_widget)
    if reg is None:
        return
    info = reg.get(app_id)
    if info is None or info.builtin:
        return

    ans = QMessageBox.question(
        parent_widget, tr("settings.apps.delete_title"),
        tr("settings.apps.delete_q", name=info.name),
        QMessageBox.Yes | QMessageBox.No)
    if ans != QMessageBox.Yes:
        return

    d = _get_desktop(parent_widget)
    if d and hasattr(d, "windows"):
        for w in list(d.windows):
            if getattr(w, "app_id", None) == app_id:
                w.close()

    reg.remove(app_id)

    if d:
        if hasattr(d, "dock"):
            d.dock.populate(d.registry.apps)
        if hasattr(d, "notifications"):
            d.notifications.push(tr("notif.app_removed"), info.name)
        if hasattr(d, "app_menu"):
            d.app_menu.set_registry(d.registry)

    _rebuild_app_list(parent_widget, holder)


def _install_from_settings(parent_widget, on_done):
    d = _get_desktop(parent_widget)
    if d is None or not hasattr(d, "registry"):
        QMessageBox.warning(parent_widget, tr("common.error"),
                            tr("settings.apps.registry_error"))
        return
    reg = d.registry

    path, _ = QFileDialog.getOpenFileName(
        parent_widget, tr("settings.apps.install_title"), "", "Python (*.py)")
    if not path:
        return

    info, err = reg.install(path)
    if err:
        QMessageBox.warning(parent_widget, tr("common.error"), err)
        return

    QMessageBox.information(parent_widget, tr("common.success"),
                            tr("settings.apps.installed_ok", name=info.name))

    if hasattr(d, "dock"):
        d.dock.populate(d.registry.apps)
    if hasattr(d, "notifications"):
        d.notifications.push(tr("notif.app_installed"),
                             f"{info.name} v{info.version}")
    if hasattr(d, "app_menu"):
        d.app_menu.set_registry(d.registry)

    if on_done:
        on_done()


def _page_system():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(2)

    lay.addWidget(_section(tr("settings.system.state")))
    uptime_lbl = QLabel("—")
    uptime_lbl.setStyleSheet("color: white; font-size: 14px; font-weight: 600; padding: 4px;")
    lay.addWidget(_row(tr("settings.system.uptime"), uptime_lbl))

    apps_lbl = QLabel("—")
    apps_lbl.setStyleSheet("color: white; font-size: 14px; font-weight: 600; padding: 4px;")
    lay.addWidget(_row(tr("settings.system.apps_count"), apps_lbl))

    wins_lbl = QLabel("—")
    wins_lbl.setStyleSheet("color: white; font-size: 14px; font-weight: 600; padding: 4px;")
    lay.addWidget(_row(tr("settings.system.windows"), wins_lbl))

    def update_stats():
        secs = int(time.time() - _START_TIME)
        h = secs // 3600; m = (secs % 3600) // 60; s = secs % 60
        uptime_lbl.setText(f"{h:02d}:{m:02d}:{s:02d}")

        reg = _get_registry(w)
        if reg:
            apps_lbl.setText(str(len(reg.apps)))

        d = _get_desktop(w)
        if d and hasattr(d, "windows"):
            wins_lbl.setText(str(len(d.windows)))

    t = QTimer(w)
    t.timeout.connect(update_stats)
    t.start(1000)
    update_stats()

    lay.addWidget(_section(tr("settings.system.control")))
    lay.addWidget(_hint(tr("settings.system.restart_hint")))

    r_row = QWidget()
    rr = QHBoxLayout(r_row)
    rr.setContentsMargins(4, 8, 4, 8)
    rr.setSpacing(10)

    restart_btn = QPushButton(f"  {tr('settings.system.restart')}")
    restart_btn.setCursor(Qt.PointingHandCursor)
    restart_btn.setStyleSheet("""
        QPushButton {
            background: rgba(110,198,255,0.18);
            color: white; border: 1px solid rgba(110,198,255,0.55);
            border-radius: 10px; padding: 10px 18px; font-size: 13px;
        }
        QPushButton:hover { background: rgba(110,198,255,0.35); }
    """)
    restart_btn.clicked.connect(_restart_mountos)
    rr.addWidget(restart_btn)

    quit_btn = QPushButton(f"  {tr('settings.system.quit')}")
    quit_btn.setCursor(Qt.PointingHandCursor)
    quit_btn.setStyleSheet("""
        QPushButton {
            background: rgba(255,107,138,0.15);
            color: #FFA0B4; border: 1px solid rgba(255,107,138,0.45);
            border-radius: 10px; padding: 10px 18px; font-size: 13px;
        }
        QPushButton:hover { background: rgba(255,107,138,0.35); color: white; }
    """)
    quit_btn.clicked.connect(QApplication.instance().quit)
    rr.addWidget(quit_btn)
    rr.addStretch(1)
    lay.addWidget(r_row)

    # ---- Reset ----
    lay.addWidget(_section(tr("settings.system.reset_title")))

    reset_btn = QPushButton(f"  {tr('settings.system.reset_title')}")
    reset_btn.setCursor(Qt.PointingHandCursor)
    reset_btn.setStyleSheet("""
        QPushButton {
            background: rgba(255,107,138,0.15);
            color: #FFA0B4;
            border: 1px solid rgba(255,107,138,0.45);
            border-radius: 10px;
            padding: 12px 18px;
            font-size: 13px;
            text-align: left;
        }
        QPushButton:hover { background: rgba(255,107,138,0.35); color: white; }
    """)

    def do_reset():
        ans = QMessageBox.question(w, tr("settings.system.reset_title"),
                                    tr("settings.system.reset_q"),
                                    QMessageBox.Yes | QMessageBox.No)
        if ans != QMessageBox.Yes:
            return
        state().reset()
        d = _get_desktop(w)
        if d and hasattr(d, "notifications"):
            d.notifications.push(tr("common.success"),
                                 tr("settings.system.reset_ok"))

    reset_btn.clicked.connect(do_reset)
    lay.addWidget(reset_btn)

    lay.addStretch(1)
    return _scrollable(w)


def _page_hotkeys():
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(30, 20, 30, 30)
    lay.setSpacing(6)

    lay.addWidget(_section(tr("settings.hotkeys.title")))
    lay.addWidget(_hint(tr("settings.hotkeys.hint")))

    for k, v in HOTKEYS_HELP:
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(16, 8, 16, 8)

        kl = QLabel(k)
        kl.setStyleSheet("""
            color: #6EC6FF;
            font-family: Consolas, monospace;
            font-size: 12px;
            font-weight: 600;
            background: rgba(110,198,255,0.10);
            border: 1px solid rgba(110,198,255,0.35);
            border-radius: 7px;
            padding: 3px 10px;
            min-width: 130px;
        """)
        rl.addWidget(kl)

        vl = QLabel(v)
        vl.setStyleSheet("color: rgba(255,255,255,0.85); font-size: 13px;")
        rl.addWidget(vl, 1)

        row.setStyleSheet("QWidget { background: rgba(255,255,255,0.04); border-radius: 10px; margin: 2px 0; }")
        lay.addWidget(row)

    lay.addStretch(1)
    return _scrollable(w)


def _restart_mountos():
    import subprocess
    QApplication.instance().quit()
    subprocess.Popen([sys.executable] + sys.argv)


# ============================================================
#  Сборка
# ============================================================

def build():
    root = QWidget()
    root.setStyleSheet("background: transparent;")
    h = QHBoxLayout(root)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(0)

    side = QWidget()
    side.setFixedWidth(230)
    side.setStyleSheet("""
        background: rgba(255,255,255,0.04);
        border-right: 1px solid rgba(255,255,255,0.08);
    """)
    sl = QVBoxLayout(side)
    sl.setContentsMargins(14, 18, 14, 18)
    sl.setSpacing(4)

    title = QLabel(f"  {tr('settings.title')}")
    title.setStyleSheet("color: white; font-size: 16px; font-weight: 600; padding: 4px 8px 16px 8px;")
    sl.addWidget(title)

    stack = QStackedWidget()
    stack.setStyleSheet("background: transparent;")

    pages = [
        ("settings", tr("settings.section.about"),      _page_about),
        ("notes",    tr("settings.section.appearance"), _page_appearance),
        ("gallery",  tr("settings.section.wallpaper"),  _page_wallpaper),
        ("globe",    tr("settings.section.language"),   _page_language),
        ("files",    tr("settings.section.apps"),       _page_apps),
        ("terminal", tr("settings.section.system"),     _page_system),
        ("grid",     tr("settings.section.hotkeys"),    _page_hotkeys),
    ]
    buttons = []

    def switch(idx):
        stack.setCurrentIndex(idx)
        for i, b in enumerate(buttons):
            b.setProperty("active", i == idx)
            b.style().unpolish(b); b.style().polish(b)

    for i, (icon_name, name, factory) in enumerate(pages):
        b = QPushButton(f"   {name}")
        b.setIcon(QIcon(get_icon(icon_name, 20, "#FFFFFF")))
        b.setIconSize(QSize(18, 18))
        b.setCursor(Qt.PointingHandCursor)
        b.setFixedHeight(40)
        b.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: rgba(255,255,255,0.75);
                border: none;
                border-radius: 10px;
                padding: 8px 12px;
                text-align: left;
                font-size: 13px;
            }
            QPushButton:hover { background: rgba(255,255,255,0.08); color: white; }
            QPushButton[active="true"] {
                background: rgba(110,198,255,0.22);
                color: white;
                border: 1px solid rgba(110,198,255,0.45);
            }
        """)
        b.clicked.connect(lambda _, i=i: switch(i))
        sl.addWidget(b)
        buttons.append(b)
        stack.addWidget(factory())

    sl.addStretch(1)
    h.addWidget(side)
    h.addWidget(stack, 1)

    switch(0)
    return root