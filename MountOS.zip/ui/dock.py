"""
MountOS — Док.
Красивые иконки с анимацией, правый клик для удаления пользовательских приложений.
"""
from PySide6.QtWidgets import QWidget, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, QSize, Signal, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QIcon

from ui.icons import get_icon
from ui.settings_state import state
from ui.context_menu import make_menu


class DockIcon(QPushButton):
    """Иконка приложения в доке."""

    delete_requested = Signal(str)   # app_id

    def __init__(self, app_id, icon_name, name, builtin=True, parent=None):
        super().__init__("", parent)
        self.app_id = app_id
        self.icon_name = icon_name
        self.builtin = builtin
        self.base_size = 52
        self.setFixedSize(self.base_size, self.base_size)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(name)

        self._active = False
        self._refresh_icon()
        self._apply_style()

        state().changed.connect(self._on_state)

    # ---------- Реакция на настройки ----------

    def _on_state(self, key, val):
        if key in ("accent",):
            self._refresh_icon()
            self._apply_style()

    def _refresh_icon(self):
        color = "#FFFFFF" if not self._active else state().get("accent")
        pm = get_icon(self.icon_name, 32, color)
        self.setIcon(QIcon(pm))
        self.setIconSize(QSize(30, 30))

    def set_active(self, active: bool):
        self._active = active
        self._refresh_icon()
        self._apply_style()

    def _apply_style(self):
        accent = state().get("accent")
        if self._active:
            bg = f"rgba({self._hex_to_rgb(accent)}, 0.30)"
            border = f"rgba({self._hex_to_rgb(accent)}, 0.75)"
        else:
            bg = "rgba(255, 255, 255, 0.10)"
            border = "rgba(255, 255, 255, 0.14)"

        self.setStyleSheet(f"""
            QPushButton {{
                background: {bg};
                border: 1px solid {border};
                border-radius: 16px;
            }}
            QPushButton:hover {{
                background: rgba(255, 255, 255, 0.26);
                border: 1px solid rgba(255, 255, 255, 0.40);
            }}
            QPushButton:pressed {{
                background: rgba({self._hex_to_rgb(accent)}, 0.55);
            }}
        """)

    @staticmethod
    def _hex_to_rgb(h: str):
        h = h.lstrip("#")
        return f"{int(h[0:2], 16)}, {int(h[2:4], 16)}, {int(h[4:6], 16)}"

    # ---------- Анимация увеличения ----------

    def enterEvent(self, e):
        self._animate(self.base_size + 10)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._animate(self.base_size)
        super().leaveEvent(e)

    def _animate(self, target):
        anim = QPropertyAnimation(self, b"size")
        anim.setDuration(150)
        anim.setStartValue(self.size())
        anim.setEndValue(QSize(target, target))
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._anim = anim

    # ---------- Правый клик ----------

    def contextMenuEvent(self, e):
        menu = make_menu(self)

        a_open = menu.addAction("Открыть")
        a_open.triggered.connect(self.click)

        if not self.builtin:
            menu.addSeparator()
            a_del = menu.addAction("🗑  Удалить приложение")
            a_del.triggered.connect(lambda: self.delete_requested.emit(self.app_id))

        menu.exec(e.globalPos())


class Dock(QWidget):
    app_launch_requested = Signal(str)
    app_install_requested = Signal()
    app_delete_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(84)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(16, 10, 16, 10)
        outer.setSpacing(10)

        self._layout = outer
        self.icons = {}
        self._install_btn = None

        self.setStyleSheet("""
            Dock {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.16);
                border-radius: 26px;
            }
        """)

    def populate(self, apps: dict):
        # очистка
        for i in reversed(range(self._layout.count())):
            w = self._layout.itemAt(i).widget()
            if w:
                w.setParent(None)

        self.icons.clear()

        # иконки приложений
        for app_id, info in apps.items():
            ic = DockIcon(app_id, info.app_id, info.name,
                          builtin=info.builtin)
            ic.clicked.connect(
                lambda _, a=app_id: self.app_launch_requested.emit(a))
            ic.delete_requested.connect(self.app_delete_requested.emit)
            self._layout.addWidget(ic)
            self.icons[app_id] = ic

        # кнопка установки
        add = QPushButton("")
        add.setToolTip("Установить приложение (.py)")
        add.setFixedSize(52, 52)
        add.setCursor(Qt.PointingHandCursor)
        accent = state().get("accent")
        add.setIcon(QIcon(get_icon("plus", 26, accent)))
        add.setIconSize(QSize(24, 24))
        add.setStyleSheet(f"""
            QPushButton {{
                background: rgba({DockIcon._hex_to_rgb(accent)}, 0.15);
                border: 1px dashed rgba({DockIcon._hex_to_rgb(accent)}, 0.60);
                border-radius: 16px;
            }}
            QPushButton:hover {{
                background: rgba({DockIcon._hex_to_rgb(accent)}, 0.35);
                border: 1px solid {accent};
            }}
        """)
        add.clicked.connect(self.app_install_requested.emit)
        self._layout.addWidget(add)
        self._install_btn = add

    def mark_active(self, app_id, active: bool):
        ic = self.icons.get(app_id)
        if ic:
            ic.set_active(active)