"""
Глобальное состояние настроек MountOS.
Читает из SettingsStore, при изменении — сохраняет.

Дополнительно:
  • следит за ключом 'language' и синхронизирует его с system.i18n
  • при загрузке сразу применяет сохранённый язык
"""
from PySide6.QtCore import QObject, Signal

from system.settings_store import SettingsStore
from system import paths


DEFAULTS = {
    # Оформление
    "accent":            "#6EC6FF",
    "window_opacity":    0.92,
    "window_radius":     22,
    "wallpaper":         "cosmic",

    # Интерфейс
    "show_clock":        True,
    "show_dock":         True,
    "show_welcome":      True,
    "show_startup_notification": True,

    # Возможности
    "blur_enabled":      True,
    "notifications_history": True,
    "hotkeys_enabled":   True,

    # Язык
    "language":          "ru",   # "ru" | "en"
}


class SettingsState(QObject):
    changed = Signal(str, object)

    def __init__(self):
        super().__init__()
        self._store = SettingsStore(paths.SETTINGS_JSON)
        self._data = dict(DEFAULTS)

        # Наложим сохранённые значения
        for k, v in self._store.all().items():
            if k in DEFAULTS:
                self._data[k] = v

        # Применяем язык сразу при старте
        self._apply_language(self._data.get("language", "ru"))

    # ---------- Чтение / запись ----------

    def get(self, key, default=None):
        return self._data.get(key, default)

    def set(self, key, value):
        if self._data.get(key) == value:
            return
        self._data[key] = value
        self._store.set(key, value)

        # Особая логика для языка
        if key == "language":
            self._apply_language(value)

        self.changed.emit(key, value)

    def all(self):
        return dict(self._data)

    # ---------- Сброс ----------

    def reset(self):
        self._data = dict(DEFAULTS)
        self._store._data = {}
        self._store.save()

        # Применяем язык заново
        self._apply_language(self._data["language"])

        for k, v in DEFAULTS.items():
            self.changed.emit(k, v)

    # ---------- Синхронизация с i18n ----------

    def _apply_language(self, lang: str):
        try:
            from system.i18n import set_language
            set_language(lang)
        except Exception as e:
            print(f"[SettingsState] не удалось применить язык {lang}: {e}")


# ---------- Синглтон ----------

_state = None


def state() -> SettingsState:
    global _state
    if _state is None:
        _state = SettingsState()
    return _state