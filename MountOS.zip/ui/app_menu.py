"""
MountOS — Меню приложений (HarmonyOS-стиль).

Полноэкранная сетка иконок всех установленных приложений
с поиском и категориями. Вызывается кнопкой в панели.
"""
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                QPushButton, QLineEdit, QScrollArea, QFrame,
                                QGraphicsDropShadowEffect, QApplication)
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, Signal, QSize
from PySide6.QtGui import QIcon, QColor

from ui.icons import get_icon
from ui.settings_state import state


class AppTile(QPushButton):
    """Плитка одного приложения в меню."""

    activated = Signal(str)
    context_requested = Signal(str, object)  # app_id, global_pos

    def __init__(self, app_id: str, name: str, icon_name: str,
                 version: str = "", builtin: bool = True, parent=None):
        super().__init__(parent)
        self.app_id = app_id
        self.icon_name = icon_name
        self.app_name = name
        self.builtin = builtin

        self.setFixedSize(140, 150)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(f"{name}\n{app_id} · v{version}"
                        + ("\n(системное)" if builtin else "\n(пользовательское)"))

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 16, 10, 12)
        lay.setSpacing(8)

        # Квадрат с иконкой
        icon_wrap = QWidget(self)
        icon_wrap.setFixedSize(72, 72)
        icon_wrap.setStyleSheet("""
            QWidget {
                background: rgba(255,255,255,0.08);
                border: 1px solid rgba(255,255,255,0.12);
                border-radius: 20px;
            }
        """)
        iw = QHBoxLayout(icon_wrap)
        iw.setContentsMargins(0, 0, 0, 0)
        iw.setAlignment(Qt.AlignCenter)

        icon_lbl = QLabel()
        icon_lbl.setPixmap(get_icon(icon_name, 40, state().get("accent")))
        icon_lbl.setStyleSheet("background: transparent; border: none;")
        iw.addWidget(icon_lbl)

        wrap_row = QHBoxLayout()
        wrap_row.addStretch(1)
        wrap_row.addWidget(icon_wrap)
        wrap_row.addStretch(1)
        lay.addLayout(wrap_row)

        # Имя
        name_lbl = QLabel(name)
        name_lbl.setAlignment(Qt.AlignCenter)
        name_lbl.setWordWrap(True)
        name_lbl.setStyleSheet("""
            color: white;
            font-size: 12px;
            font-weight: 500;
            background: transparent;
        """)
        lay.addWidget(name_lbl)

        lay.addStretch(1)

        self.setStyleSheet("""
            AppTile {
                background: transparent;
                border: none;
                border-radius: 18px;
            }
            AppTile:hover {
                background: rgba(255,255,255,0.08);
            }
            AppTile:pressed {
                background: rgba(110,198,255,0.20);
            }
        """)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.activated.emit(self.app_id)
        super().mouseReleaseEvent(e)

    def contextMenuEvent(self, e):
        self.context_requested.emit(self.app_id, e.globalPos())


class AppMenu(QWidget):
    """
    Полноэкранное меню приложений.
    Показывается поверх рабочего стола с плавной анимацией.
    """

    app_launch_requested = Signal(str)
    app_delete_requested = Signal(str)
    app_install_requested = Signal()

    def __init__(self, host: QWidget):
        super().__init__(host)
        self.host = host
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.hide()

        self._visible = False
        self._registry = None

        # Затемняющая подложка
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Верхняя полоса: поиск + закрыть
        top = QWidget(self)
        top.setFixedHeight(90)
        top.setStyleSheet("background: transparent;")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(60, 30, 60, 10)
        tl.setSpacing(16)

        title = QLabel("Все приложения")
        title.setStyleSheet("""
            color: white;
            font-size: 22px;
            font-weight: 300;
            letter-spacing: 1px;
            background: transparent;
        """)
        tl.addWidget(title)

        tl.addStretch(1)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Поиск приложений…")
        self.search.setFixedWidth(300)
        self.search.setStyleSheet("""
            QLineEdit {
                background: rgba(255,255,255,0.10);
                color: white;
                border: 1px solid rgba(255,255,255,0.18);
                border-radius: 12px;
                padding: 9px 14px;
                font-size: 13px;
            }
            QLineEdit:focus { border: 1px solid rgba(110,198,255,0.65); }
        """)
        self.search.textChanged.connect(self._filter)
        tl.addWidget(self.search)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(38, 38)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255,255,255,0.08);
                color: rgba(255,255,255,0.85);
                border: 1px solid rgba(255,255,255,0.14);
                border-radius: 12px;
                font-size: 15px;
            }
            QPushButton:hover {
                background: rgba(255,107,138,0.35);
                color: white;
            }
        """)
        close_btn.clicked.connect(self.hide_menu)
        tl.addWidget(close_btn)

        outer.addWidget(top)

        # Область со скроллом
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical {
                background: transparent; width: 8px; margin: 4px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255,255,255,0.20);
                border-radius: 4px; min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255,255,255,0.35);
            }
            QScrollBar::add-line, QScrollBar::sub-line { height: 0; }
        """)

        self._holder = QWidget()
        self._holder.setStyleSheet("background: transparent;")
        self._grid = QVBoxLayout(self._holder)
        self._grid.setContentsMargins(60, 10, 60, 60)
        self._grid.setSpacing(20)

        self.scroll.setWidget(self._holder)
        outer.addWidget(self.scroll, 1)

        # Empty label
        self.empty_lbl = QLabel("Ничего не найдено")
        self.empty_lbl.setAlignment(Qt.AlignCenter)
        self.empty_lbl.setStyleSheet("""
            color: rgba(255,255,255,0.45);
            font-size: 15px;
            padding: 60px;
            background: transparent;
        """)
        self.empty_lbl.hide()

        # Подложка при клике на пустое место
        self.setStyleSheet("AppMenu { background: rgba(0,0,0,0.45); }")

    # ---------- Registry ----------

    def set_registry(self, registry):
        self._registry = registry

    # ---------- Показ / скрытие ----------

    def show_menu(self):
        if self._visible:
            return
        self._rebuild()
        self.search.clear()
        self.search.setFocus()

        self.setGeometry(self.host.rect())
        self.show()
        self.raise_()

        # Плавное появление через прозрачность
        self.setWindowOpacity(0.0)
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(220)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.start()
        self._anim = anim
        self._visible = True

    def hide_menu(self):
        if not self._visible:
            return
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(180)
        anim.setEasingCurve(QEasingCurve.InCubic)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.finished.connect(self._after_hide)
        anim.start()
        self._anim = anim
        self._visible = False

    def _after_hide(self):
        if not self._visible:
            self.hide()

    def toggle(self):
        if self._visible:
            self.hide_menu()
        else:
            self.show_menu()

    # ---------- Построение сетки ----------

    def _rebuild(self):
        # Очистка сетки
        while self._grid.count():
            it = self._grid.takeAt(0)
            w = it.widget()
            if w and w is not self.empty_lbl:
                w.setParent(None)
            elif w is self.empty_lbl:
                w.setParent(None)

        self.empty_lbl.setParent(None)

        if self._registry is None:
            self._grid.addWidget(self.empty_lbl)
            self.empty_lbl.show()
            return

        apps = self._registry.apps

        # Разделим: системные и пользовательские
        builtin = [(k, v) for k, v in apps.items() if v.builtin]
        custom  = [(k, v) for k, v in apps.items() if not v.builtin]

        builtin.sort(key=lambda kv: kv[1].name.lower())
        custom.sort(key=lambda kv: kv[1].name.lower())

        if builtin:
            self._grid.addWidget(self._section_label("Системные"))
            self._grid.addWidget(self._build_row(builtin))

        if custom:
            self._grid.addWidget(self._section_label("Пользовательские"))
            self._grid.addWidget(self._build_row(custom))

        if not builtin and not custom:
            self._grid.addWidget(self.empty_lbl)
            self.empty_lbl.show()

    def _section_label(self, text: str) -> QLabel:
        l = QLabel(text.upper())
        l.setStyleSheet("""
            color: rgba(255,255,255,0.40);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 2px;
            background: transparent;
            padding: 4px 0;
        """)
        return l

    def _build_row(self, apps) -> QWidget:
        row = QWidget()
        row.setStyleSheet("background: transparent;")
        rl = QHBoxLayout(row)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(10)
        rl.setAlignment(Qt.AlignLeft)

        for app_id, info in apps:
            tile = AppTile(
                app_id=app_id,
                name=info.name,
                icon_name=info.app_id,
                version=info.version,
                builtin=info.builtin,
            )
            tile.activated.connect(self._on_tile)
            tile.context_requested.connect(self._on_tile_context)
            rl.addWidget(tile)

        rl.addStretch(1)
        return row

    def _on_tile(self, app_id: str):
        self.hide_menu()
        self.app_launch_requested.emit(app_id)

    def _on_tile_context(self, app_id: str, global_pos):
        from ui.context_menu import make_menu
        menu = make_menu(self)
        a_open = menu.addAction("Открыть")
        a_open.triggered.connect(lambda: self._on_tile(app_id))

        if self._registry and app_id in self._registry.apps:
            info = self._registry.apps[app_id]
            if not info.builtin:
                menu.addSeparator()
                a_del = menu.addAction("🗑  Удалить приложение")
                a_del.triggered.connect(
                    lambda: self.app_delete_requested.emit(app_id))

        menu.exec(global_pos)

    # ---------- Поиск ----------

    def _filter(self, query: str):
        query = (query or "").strip().lower()

        if self._registry is None:
            return

        apps = self._registry.apps
        builtin = [(k, v) for k, v in apps.items() if v.builtin]
        custom  = [(k, v) for k, v in apps.items() if not v.builtin]

        def match(item):
            _, info = item
            if not query:
                return True
            return (query in info.name.lower()
                    or query in info.app_id.lower()
                    or query in getattr(info, "author", "").lower())

        builtin = [i for i in builtin if match(i)]
        custom  = [i for i in custom if match(i)]
        builtin.sort(key=lambda kv: kv[1].name.lower())
        custom.sort(key=lambda kv: kv[1].name.lower())

        while self._grid.count():
            it = self._grid.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)

        self.empty_lbl.setParent(None)

        if not builtin and not custom:
            self._grid.addWidget(self.empty_lbl)
            self.empty_lbl.show()
            return

        if builtin:
            self._grid.addWidget(self._section_label("Системные"))
            self._grid.addWidget(self._build_row(builtin))

        if custom:
            self._grid.addWidget(self._section_label("Пользовательские"))
            self._grid.addWidget(self._build_row(custom))

    # ---------- Реакция на клавиши ----------

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide_menu()
        elif e.key() in (Qt.Key_Return, Qt.Key_Enter):
            if self.search.text().strip():
                # Запускаем первое совпадение
                apps = self._registry.apps if self._registry else {}
                q = self.search.text().strip().lower()
                for app_id, info in apps.items():
                    if q in info.name.lower() or q in app_id.lower():
                        self._on_tile(app_id)
                        return
        super().keyPressEvent(e)

    # ---------- Обновление при изменении размера ----------

    def resizeEvent(self, e):
        self.setGeometry(self.host.rect())
        super().resizeEvent(e)