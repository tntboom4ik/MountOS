"""
Векторные иконки MountOS.
Рисуются QPainter'ом — не зависят от шрифтов и эмодзи.
"""
from PySide6.QtGui import QPixmap, QPainter, QColor, QPen, QBrush, QPainterPath
from PySide6.QtCore import Qt, QRectF, QPointF
import math


def _canvas(size):
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    return pm, p


# ============================================================
#  Базовые иконки
# ============================================================

def _icon_folder(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    path.moveTo(s * 0.12, s * 0.30)
    path.lineTo(s * 0.42, s * 0.30)
    path.lineTo(s * 0.50, s * 0.40)
    path.lineTo(s * 0.88, s * 0.40)
    path.lineTo(s * 0.88, s * 0.78)
    path.lineTo(s * 0.12, s * 0.78)
    path.closeSubpath()
    p.drawPath(path)
    p.end()
    return pm


def _icon_terminal(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.075); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawRoundedRect(QRectF(s * 0.10, s * 0.18, s * 0.80, s * 0.64), s * 0.10, s * 0.10)
    p.drawLine(QPointF(s * 0.24, s * 0.38), QPointF(s * 0.36, s * 0.50))
    p.drawLine(QPointF(s * 0.36, s * 0.50), QPointF(s * 0.24, s * 0.62))
    p.drawLine(QPointF(s * 0.46, s * 0.64), QPointF(s * 0.68, s * 0.64))
    p.end()
    return pm


def _icon_notes(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    p.drawRoundedRect(QRectF(s * 0.18, s * 0.12, s * 0.64, s * 0.76), s * 0.08, s * 0.08)
    pen.setWidthF(s * 0.05); p.setPen(pen)
    for y in (0.36, 0.52, 0.68):
        p.drawLine(QPointF(s * 0.30, s * y), QPointF(s * 0.70, s * y))
    p.end()
    return pm


def _icon_settings(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.075); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    cx, cy = s / 2, s / 2
    r1, r2 = s * 0.16, s * 0.34
    p.drawEllipse(QPointF(cx, cy), r1, r1)
    for i in range(8):
        a = math.radians(i * 45)
        x1 = cx + math.cos(a) * r1 * 1.1
        y1 = cy + math.sin(a) * r1 * 1.1
        x2 = cx + math.cos(a) * r2
        y2 = cy + math.sin(a) * r2
        p.drawLine(QPointF(x1, y1), QPointF(x2, y2))
    p.end()
    return pm


def _icon_calc(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.065); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    p.drawRoundedRect(QRectF(s * 0.18, s * 0.10, s * 0.64, s * 0.80), s * 0.10, s * 0.10)
    pen.setWidthF(s * 0.05); p.setPen(pen)
    p.drawLine(QPointF(s * 0.28, s * 0.24), QPointF(s * 0.72, s * 0.24))
    for row in range(3):
        for col in range(3):
            x = s * 0.30 + col * s * 0.15
            y = s * 0.42 + row * s * 0.15
            p.drawPoint(QPointF(x, y))
    p.end()
    return pm


def _icon_globe(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07)
    p.setPen(pen)
    p.drawEllipse(QRectF(s * 0.14, s * 0.14, s * 0.72, s * 0.72))
    p.drawEllipse(QRectF(s * 0.34, s * 0.14, s * 0.32, s * 0.72))
    p.drawLine(QPointF(s * 0.14, s * 0.50), QPointF(s * 0.86, s * 0.50))
    p.end()
    return pm


def _icon_plus(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.09); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.5, s * 0.22), QPointF(s * 0.5, s * 0.78))
    p.drawLine(QPointF(s * 0.22, s * 0.5), QPointF(s * 0.78, s * 0.5))
    p.end()
    return pm


def _icon_trash(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.065)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.22, s * 0.28), QPointF(s * 0.78, s * 0.28))
    p.drawRect(QRectF(s * 0.28, s * 0.28, s * 0.44, s * 0.58))
    p.drawLine(QPointF(s * 0.40, s * 0.18), QPointF(s * 0.60, s * 0.18))
    p.end()
    return pm


def _icon_back(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.09); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.62, s * 0.24), QPointF(s * 0.36, s * 0.50))
    p.drawLine(QPointF(s * 0.36, s * 0.50), QPointF(s * 0.62, s * 0.76))
    p.end()
    return pm


# ============================================================
#  Иконки приложений
# ============================================================

def _icon_gallery(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(QRectF(s * 0.12, s * 0.18, s * 0.76, s * 0.64), s * 0.08, s * 0.08)
    p.setBrush(QBrush(QColor(color))); p.setPen(Qt.NoPen)
    p.drawEllipse(QPointF(s * 0.34, s * 0.38), s * 0.07, s * 0.07)
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.065)
    pen.setJoinStyle(Qt.RoundJoin); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    path.moveTo(s * 0.16, s * 0.72)
    path.lineTo(s * 0.36, s * 0.50)
    path.lineTo(s * 0.52, s * 0.66)
    path.lineTo(s * 0.68, s * 0.48)
    path.lineTo(s * 0.84, s * 0.72)
    p.drawPath(path)
    p.end()
    return pm


def _icon_music(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.42, s * 0.22), QPointF(s * 0.42, s * 0.70))
    p.drawLine(QPointF(s * 0.72, s * 0.30), QPointF(s * 0.72, s * 0.66))
    pen.setWidthF(s * 0.08); p.setPen(pen)
    p.drawLine(QPointF(s * 0.42, s * 0.22), QPointF(s * 0.72, s * 0.30))
    p.setBrush(QBrush(QColor(color))); p.setPen(Qt.NoPen)
    p.drawEllipse(QPointF(s * 0.34, s * 0.70), s * 0.11, s * 0.085)
    p.drawEllipse(QPointF(s * 0.64, s * 0.66), s * 0.11, s * 0.085)
    p.end()
    return pm


def _icon_taskmgr(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.075); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.24, s * 0.72), QPointF(s * 0.24, s * 0.52))
    p.drawLine(QPointF(s * 0.44, s * 0.72), QPointF(s * 0.44, s * 0.36))
    p.drawLine(QPointF(s * 0.64, s * 0.72), QPointF(s * 0.64, s * 0.22))
    pen.setWidthF(s * 0.05); p.setPen(pen)
    p.drawLine(QPointF(s * 0.14, s * 0.82), QPointF(s * 0.86, s * 0.82))
    p.end()
    return pm


def _icon_clock(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawEllipse(QRectF(s * 0.14, s * 0.14, s * 0.72, s * 0.72))
    p.drawLine(QPointF(s * 0.50, s * 0.50), QPointF(s * 0.50, s * 0.28))
    p.drawLine(QPointF(s * 0.50, s * 0.50), QPointF(s * 0.72, s * 0.50))
    p.setBrush(QBrush(QColor(color))); p.setPen(Qt.NoPen)
    for x, y in [(0.5, 0.16), (0.84, 0.5), (0.5, 0.84), (0.16, 0.5)]:
        p.drawEllipse(QPointF(s * x, s * y), s * 0.035, s * 0.035)
    p.end()
    return pm


def _icon_calendar(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(QRectF(s * 0.14, s * 0.20, s * 0.72, s * 0.68), s * 0.08, s * 0.08)
    p.drawLine(QPointF(s * 0.14, s * 0.38), QPointF(s * 0.86, s * 0.38))
    pen.setWidthF(s * 0.065); pen.setCapStyle(Qt.RoundCap); p.setPen(pen)
    p.drawLine(QPointF(s * 0.32, s * 0.14), QPointF(s * 0.32, s * 0.26))
    p.drawLine(QPointF(s * 0.68, s * 0.14), QPointF(s * 0.68, s * 0.26))
    p.setBrush(QBrush(QColor(color))); p.setPen(Qt.NoPen)
    for row in range(2):
        for col in range(3):
            x = s * 0.30 + col * s * 0.20
            y = s * 0.52 + row * s * 0.16
            p.drawEllipse(QPointF(x, y), s * 0.028, s * 0.028)
    p.end()
    return pm


def _icon_editor(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07); pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    path.moveTo(s * 0.22, s * 0.14)
    path.lineTo(s * 0.62, s * 0.14)
    path.lineTo(s * 0.78, s * 0.30)
    path.lineTo(s * 0.78, s * 0.86)
    path.lineTo(s * 0.22, s * 0.86)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(s * 0.62, s * 0.14), QPointF(s * 0.62, s * 0.30))
    p.drawLine(QPointF(s * 0.62, s * 0.30), QPointF(s * 0.78, s * 0.30))
    pen.setWidthF(s * 0.045); pen.setCapStyle(Qt.RoundCap); p.setPen(pen)
    for y in (0.48, 0.60, 0.72):
        p.drawLine(QPointF(s * 0.34, s * y), QPointF(s * 0.66, s * y))
    p.end()
    return pm


def _icon_bell(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07)
    pen.setJoinStyle(Qt.RoundJoin); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    path.moveTo(s * 0.30, s * 0.62)
    path.lineTo(s * 0.30, s * 0.42)
    path.quadTo(s * 0.30, s * 0.20, s * 0.50, s * 0.20)
    path.quadTo(s * 0.70, s * 0.20, s * 0.70, s * 0.42)
    path.lineTo(s * 0.70, s * 0.62)
    p.drawPath(path)
    p.drawLine(QPointF(s * 0.26, s * 0.62), QPointF(s * 0.74, s * 0.62))
    p.drawLine(QPointF(s * 0.44, s * 0.70), QPointF(s * 0.56, s * 0.70))
    p.drawLine(QPointF(s * 0.44, s * 0.70), QPointF(s * 0.50, s * 0.78))
    p.drawLine(QPointF(s * 0.56, s * 0.70), QPointF(s * 0.50, s * 0.78))
    p.end()
    return pm


def _icon_grid(size, color):
    pm, p = _canvas(size)
    s = size
    p.setPen(Qt.NoPen); p.setBrush(QBrush(QColor(color)))
    for r in range(3):
        for c in range(3):
            x = s * 0.24 + c * s * 0.20
            y = s * 0.24 + r * s * 0.20
            p.drawEllipse(QPointF(x, y), s * 0.06, s * 0.06)
    p.end()
    return pm


def _icon_search(size, color):
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.08); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    p.drawEllipse(QRectF(s * 0.18, s * 0.18, s * 0.48, s * 0.48))
    p.drawLine(QPointF(s * 0.60, s * 0.60), QPointF(s * 0.82, s * 0.82))
    p.end()
    return pm


# ============================================================
#  Иконки для браузера
# ============================================================

def _icon_browser(size, color):
    """Глобус + кольцо-орбита."""
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    # Глобус
    p.drawEllipse(QRectF(s * 0.14, s * 0.14, s * 0.72, s * 0.72))
    p.drawEllipse(QRectF(s * 0.34, s * 0.14, s * 0.32, s * 0.72))
    p.drawLine(QPointF(s * 0.14, s * 0.50), QPointF(s * 0.86, s * 0.50))
    # Кольцо наклонённое (орбита)
    pen.setWidthF(s * 0.05)
    p.setPen(pen)
    p.save()
    p.translate(s / 2, s / 2)
    p.rotate(-25)
    p.drawEllipse(QRectF(-s * 0.42, -s * 0.14, s * 0.84, s * 0.28))
    p.restore()
    p.end()
    return pm


def _icon_forward(size, color):
    """Стрелка вперёд (правая)."""
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.09); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.drawLine(QPointF(s * 0.38, s * 0.24), QPointF(s * 0.64, s * 0.50))
    p.drawLine(QPointF(s * 0.64, s * 0.50), QPointF(s * 0.38, s * 0.76))
    p.end()
    return pm


def _icon_reload(size, color):
    """Круговая стрелка."""
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.08); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    # Дуга
    rect = QRectF(s * 0.18, s * 0.18, s * 0.64, s * 0.64)
    p.drawArc(rect, 45 * 16, 270 * 16)
    # Стрелка на конце
    p.setBrush(QBrush(QColor(color)))
    p.setPen(Qt.NoPen)
    # Треугольник на конце дуги
    arrow = QPainterPath()
    end_x = s * 0.82
    end_y = s * 0.42
    arrow.moveTo(end_x, end_y)
    arrow.lineTo(end_x - s * 0.15, end_y - s * 0.03)
    arrow.lineTo(end_x - s * 0.05, end_y + s * 0.14)
    arrow.closeSubpath()
    p.drawPath(arrow)
    p.end()
    return pm


def _icon_home(size, color):
    """Домик."""
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.075)
    pen.setJoinStyle(Qt.RoundJoin); pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    path.moveTo(s * 0.16, s * 0.48)
    path.lineTo(s * 0.50, s * 0.18)
    path.lineTo(s * 0.84, s * 0.48)
    p.drawPath(path)
    p.drawRect(QRectF(s * 0.26, s * 0.48, s * 0.48, s * 0.36))
    # Дверь
    p.drawRect(QRectF(s * 0.42, s * 0.64, s * 0.16, s * 0.20))
    p.end()
    return pm


def _icon_star(size, color):
    """Звёздочка (закладка)."""
    pm, p = _canvas(size)
    s = size
    pen = QPen(QColor(color)); pen.setWidthF(s * 0.07)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.NoBrush)
    path = QPainterPath()
    cx, cy = s * 0.5, s * 0.52
    outer = s * 0.36
    inner = s * 0.15
    for i in range(10):
        a = math.radians(-90 + i * 36)
        r = outer if i % 2 == 0 else inner
        x = cx + math.cos(a) * r
        y = cy + math.sin(a) * r
        if i == 0:
            path.moveTo(x, y)
        else:
            path.lineTo(x, y)
    path.closeSubpath()
    p.drawPath(path)
    p.end()
    return pm


def _icon_star_filled(size, color):
    """Залитая звёздочка."""
    pm, p = _canvas(size)
    s = size
    p.setPen(Qt.NoPen); p.setBrush(QBrush(QColor(color)))
    path = QPainterPath()
    cx, cy = s * 0.5, s * 0.52
    outer = s * 0.36
    inner = s * 0.15
    for i in range(10):
        a = math.radians(-90 + i * 36)
        r = outer if i % 2 == 0 else inner
        x = cx + math.cos(a) * r
        y = cy + math.sin(a) * r
        if i == 0:
            path.moveTo(x, y)
        else:
            path.lineTo(x, y)
    path.closeSubpath()
    p.drawPath(path)
    p.end()
    return pm


# ============================================================
#  Реестр
# ============================================================

_REGISTRY = {
    # базовые
    "files":      _icon_folder,
    "terminal":   _icon_terminal,
    "notes":      _icon_notes,
    "settings":   _icon_settings,
    "calculator": _icon_calc,
    "globe":      _icon_globe,
    "plus":       _icon_plus,
    "trash":      _icon_trash,
    "back":       _icon_back,

    # приложения
    "gallery":    _icon_gallery,
    "music":      _icon_music,
    "taskmgr":    _icon_taskmgr,
    "clock":      _icon_clock,
    "calendar":   _icon_calendar,
    "editor":     _icon_editor,
    "bell":       _icon_bell,
    "grid":       _icon_grid,
    "search":     _icon_search,

    # браузер и его элементы
    "browser":    _icon_browser,
    "forward":    _icon_forward,
    "reload":     _icon_reload,
    "home":       _icon_home,
    "star":       _icon_star,
    "star_filled":_icon_star_filled,

    # алиасы
    "text_editor": _icon_editor,
}


def get_icon(name: str, size: int = 32, color: str = "#FFFFFF") -> QPixmap:
    fn = _REGISTRY.get(name)
    if fn is None:
        return _icon_globe(size, color)
    return fn(size, color)


def available_icons():
    return sorted(_REGISTRY.keys())