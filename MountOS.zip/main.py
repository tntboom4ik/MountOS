"""
MountOS — точка входа.
"""
import sys
import os

# ============================================================
#  GPU-ускорение Chromium — ДО первого импорта PySide6.QtWebEngine*
# ============================================================
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", (
    "--enable-gpu-rasterization "
    "--enable-zero-copy "
    "--enable-accelerated-2d-canvas "
    "--ignore-gpu-blocklist "
    "--enable-features=VaapiVideoDecoder,CanvasOopRasterization,UseSkiaRenderer "
    "--disable-features=CalculateNativeWinOcclusion,UseChromeOSDirectVideoDecoder "
    "--disable-background-timer-throttling "
    "--disable-renderer-backgrounding "
    "--disable-backgrounding-occluded-windows"
))

# ============================================================
#  BASE_DIR (работает и из .exe, и из исходников)
# ============================================================
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtCore import QTimer


def _pick_font(app: QApplication):
    """Подбирает кроссплатформенный шрифт интерфейса."""
    try:
        families = set(QFontDatabase.families())
    except Exception:
        families = set()
    for name in ("Inter", "Segoe UI", "Ubuntu", "Cantarell",
                 "Noto Sans", "DejaVu Sans", "Arial"):
        if name in families:
            app.setFont(QFont(name, 10))
            return name
    return None


def _warmup_webengine():
    """Прогревает Chromium в фоне."""
    try:
        from PySide6.QtWebEngineCore import QWebEngineProfile
        QWebEngineProfile.defaultProfile()
        print("[MountOS] Chromium прогрет")
    except Exception as e:
        print(f"[MountOS] прогрев Chromium: {e}")


def main():
    # ---- Первая инициализация ----
    from system.paths import first_run_init
    first_run_init()

    # ---- QApplication ----
    app = QApplication(sys.argv)
    app.setApplicationName("MountOS")
    app.setOrganizationName("MountOS")

    chosen = _pick_font(app)
    if chosen:
        print(f"[MountOS] шрифт интерфейса: {chosen}")

    # ---- Настройки ----
    from ui.settings_state import state
    st = state()
    print(f"[MountOS] настройки загружены: accent={st.get('accent')} "
          f"wallpaper={st.get('wallpaper')}")

    # ---- История уведомлений ----
    from system.notify_history import history
    h = history()
    print(f"[MountOS] история уведомлений: {len(h)} записей, "
          f"{h.unread_count()} непрочитанных")

    # ---- Рабочий стол ----
    from ui.desktop import Desktop
    desktop = Desktop(BASE_DIR)
    desktop.showFullScreen()

    # ---- Прогрев Chromium через 2 сек ----
    QTimer.singleShot(2000, _warmup_webengine)

    print("[MountOS] готово. Горячие клавиши:")
    try:
        from ui.hotkeys import HOTKEYS_HELP
        for k, v in HOTKEYS_HELP:
            print(f"  {k:18} — {v}")
    except Exception:
        pass

    sys.exit(app.exec())


if __name__ == "__main__":
    main()